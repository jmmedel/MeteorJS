Meteor.subscribe('products');

Meteor.subscribe('categories');