Meteor.methods({
  'Meetups.insert': function (params) {
    Meetups.insert(params);
  }
});
