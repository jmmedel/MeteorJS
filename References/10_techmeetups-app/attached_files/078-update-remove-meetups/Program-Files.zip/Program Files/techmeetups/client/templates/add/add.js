Template.addMeetup.onRendered(function(){
	this.$('.datetimepicker').datetimepicker();
});