Accounts.ui.config({
	passwordSignupFields: 'USERNAME_ONLY'
});